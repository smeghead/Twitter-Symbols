# Twitter Symbols #

This is Chrome Extention. Chrome Extentions. At Twitter official web site, support to insert symbols.

## INSTALL ##

by Chrome(Web Browser), open https://chrome.google.com/extensions/detail/bjbolaacbpibnnbfnebejhonbdbmpifa and click install.
